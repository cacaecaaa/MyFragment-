data class CropTop(
    var name: String = "",
    var price: String = "",
    var photo: Int = 0
)