package com.example.uklrecyclerview

import CropTop

object CropTopData {
    private val data = arrayOf(
        arrayOf(
            "Crop Top Black Singlet (ButterFly)",
            "IDR 350.000",
            R.drawable.croptopblack
        ),
        arrayOf(
            "Crop Top White (Butterfly)",
            "IDR 250.000",
            R.drawable.croptopbutterflywhite
        ),
        arrayOf(
            "Crop Top Olive (Butterfly",
            "IDR 150,000",
            R.drawable.croptopgreen
        ),
        arrayOf(
            "Shirt Top Grey",
            "IDR 700,000",
            R.drawable.croptopgrey
        ),
        arrayOf(
            "Crop Top Serut Tali",
            "IDR 300,000",
            R.drawable.croptoptali
        ),
        arrayOf(
            "Darlingaga Top White",
            "IDR 800,000",
            R.drawable.croptopdarlingaga
        )
    )

    val listData: ArrayList<CropTop>
        get() {
            val list = arrayListOf<CropTop>()
            for (aData in data) {
                val croptop = CropTop()
                croptop.name = aData[0] as String
                croptop.price = aData[1] as String
                croptop.photo = aData[2] as Int

                list.add(croptop)


            }

            return list
        }
}